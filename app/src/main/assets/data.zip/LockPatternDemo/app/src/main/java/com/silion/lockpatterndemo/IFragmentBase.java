package com.silion.lockpatterndemo;

/**
 * Created by silion on 2015/10/26.
 */
public interface IFragmentBase {
    void updataActionBar();

    void onBackPressed();
}
